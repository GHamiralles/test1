var story = {
 "pages": [
  {
   "image": "Current i360.png",
   "image2x": "Current i360@2x.png",
   "width": 2082,
   "links": [{
    "rect": [
     446,
     126,
     728,
     185
    ],
    "page": 1
   }],
   "title": "Current i360",
   "height": 770
  },
  {
   "image": "Current i360 001.png",
   "image2x": "Current i360 001@2x.png",
   "width": 2162,
   "links": [{
    "rect": [
     40,
     326,
     322,
     385
    ],
    "page": 2
   }],
   "title": "Current i360 001",
   "height": 1063
  },
  {
   "image": "Current i360 002.png",
   "image2x": "Current i360 002@2x.png",
   "width": 2186,
   "links": [],
   "title": "Current i360 002",
   "height": 1344
  },
  {
   "image": "Current i360 003.png",
   "image2x": "Current i360 003@2x.png",
   "width": 2109,
   "links": [],
   "title": "Current i360 003",
   "height": 1834
  }
 ],
 "resolutions": [2],
 "title": "Updated i360 Personal Update",
 "highlightLinks": false
}